SELECT c_address as adress, c_phone as phone_number, c_acctbal as account_balance FROM Customer WHERE c_custkey=000000010;
